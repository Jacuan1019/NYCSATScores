//
//  SchoolViewController.h
//  NYCSATScores
//
//  Created by Consultant on 11/2/19.
//  Copyright © 2019 J M. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SchoolNetwork.h"

NS_ASSUME_NONNULL_BEGIN

@interface SchoolViewController : UIViewController

@property (strong, nonatomic) SchoolNetwork *network;

- (void)updateScores:(NSInteger)scores;
- (void)updateNumbLabel:(NSInteger)numb;

@end

NS_ASSUME_NONNULL_END
