//
//  SchoolViewController.m
//  NYCSATScores
//
//  Created by Consultant on 11/2/19.
//  Copyright © 2019 J M. All rights reserved.
//

#import "SchoolViewController.h"

@interface SchoolViewController ()

@property (strong, nonatomic) IBOutlet School *schoolLabel;

@property (strong, nonatomic) IBOutlet Numb *numbLabel;
@property (strong, nonatomic) IBOutlet Scores *numbLabel;


@end

@implementation SchoolViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:@"https://data.cityofnewyork.us/resource/s3k6-pzi2.json"]];
   

        
    }


@end
