//
//  SchoolNetwork.m
//  NYCSATScores
//
//  Created by Consultant on 11/2/19.
//  Copyright © 2019 J M. All rights reserved.
//

#import "SchoolNetwork.h"
#import "SchoolParser.h"


typedef void (^DataTaskComp)(NSData *, NSURLResponse *, NSError *);

@interface SchoolNetwork ()

@property (nonatomic, strong) NSURLSession *session;
@property (nonatomic, strong) SchoolParser *parser;

@end

@implementation SchoolNetwork

- (instancetype)init {
    self = [super init];
    if (self) {
        self.session = [NSURLSession sessionWithConfiguration:NSURLSessionConfiguration.defaultSessionConfiguration];
        self.parser = [[SchoolParser alloc] init];
    }
    return self;
}


- (void)SchoolName:(NSString *)name
       completion:(void (^)(SchoolResponse *))completion {
    
    
    NSString *base = @"https://data.cityofnewyork.us/resource/s3k6-pzi2.json";
    NSString *urlString = [NSString stringWithFormat:@"%@%@", base, name];
    NSURL *url = [NSURL URLWithString:urlString];
    
    
    
    DataTaskComp dataTaskComp = ^(NSData *data, NSURLResponse *resp, NSError *err) {
        
        SchoolResponse *response = [self.parser parseData:data];
        
        completion(response);
    };
    
    NSURLSessionDataTask *dataTask = [self.session dataTaskWithURL:url completionHandler:dataTaskComp];
    
    [dataTask resume];
    
}

@end
