//
//  SchoolParser.m
//  NYCSATScores
//
//  Created by Consultant on 11/2/19.
//  Copyright © 2019 J M. All rights reserved.
//

#import "SchoolParser.h"

@implementation SchoolParser


- (SchoolResponse *)parseData:(NSData *)data {
    NSError *myError;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data
                                                         options:NSJSONReadingMutableLeaves
                                                           error:&myError];
    if (myError != nil) {
        NSLog(@"%@", [myError debugDescription]);
        return nil;
    }
    
    NSString *school = json[@"school"];
    NSInteger numb;
    

    if (json[@"numb"] != [NSNull null]) {
        numb = [json[@"numb"] integerValue];
    }
    else {
        numb = -1;
    }
    NSInteger scores = [json[@"scores"] integerValue];
    
   
    SchoolResponse *response = [[SchoolResponse alloc] init];
    response.school = school;
    response.numb = numb;
    response.scores = scores;
    
    return response;
}

@end


