//
//  SchoolParser.h
//  NYCSATScores
//
//  Created by Consultant on 11/2/19.
//  Copyright © 2019 J M. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SchoolResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface SchoolParser : NSObject

- (SchoolResponse *)parseData:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
