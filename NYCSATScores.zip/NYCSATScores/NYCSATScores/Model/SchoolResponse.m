//
//  SchoolResponse.m
//  NYCSATScores
//
//  Created by Consultant on 11/2/19.
//  Copyright © 2019 J M. All rights reserved.
//

#import "SchoolResponse.h"

@implementation SchoolResponse

@end
