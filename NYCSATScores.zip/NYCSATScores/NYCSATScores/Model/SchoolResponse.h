//
//  SchoolResponse.h
//  NYCSATScores
//
//  Created by Consultant on 11/2/19.
//  Copyright © 2019 J M. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SchoolResponse : NSObject

@property NSString *school;
@property NSInteger numb;
@property NSInteger scores;

@end

NS_ASSUME_NONNULL_END
